package lv.javaguru.java2;

public class Test {

}
